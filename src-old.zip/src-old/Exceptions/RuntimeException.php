<?php

declare(strict_types=1);

namespace Daycry\RestFul\Exceptions;

class RuntimeException extends \RuntimeException implements BaseException
{
}
