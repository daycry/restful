<?php

declare(strict_types=1);

namespace Daycry\RestFul\Exceptions;

class LogicException extends \LogicException implements BaseException
{
}
